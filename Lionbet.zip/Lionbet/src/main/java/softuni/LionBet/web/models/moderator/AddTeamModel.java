package softuni.LionBet.web.models.moderator;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class AddTeamModel {
    private String name;
}
