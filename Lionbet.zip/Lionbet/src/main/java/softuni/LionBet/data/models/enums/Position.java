package softuni.LionBet.data.models.enums;

public enum Position {
    GK, DEF, MID, ATT
}
