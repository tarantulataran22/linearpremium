package softuni.LionBet.service.models;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class UserRankingServiceModel {
    private String username;
    private int points;
}
