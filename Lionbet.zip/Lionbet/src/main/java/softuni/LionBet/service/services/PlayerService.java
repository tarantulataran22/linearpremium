package softuni.LionBet.service.services;

import softuni.LionBet.service.models.moderator.AddPlayerServiceModel;

public interface PlayerService {
    void addPlayer(AddPlayerServiceModel model);
}
