package softuni.LionBet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LionBetApplication {

	public static void main(String[] args) {
		SpringApplication.run(LionBetApplication.class, args);
	}

}
